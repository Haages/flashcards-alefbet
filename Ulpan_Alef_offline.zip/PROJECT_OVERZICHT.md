# Ulpan Morasha Alef 2025/2026 — Project overzicht

© 2026 Jessica Haages — Alle rechten voorbehouden. Zie `LICENSE.txt`.

Dit document beschrijft alles wat is gemaakt voor de offline backup en oefenomgeving van de Ulpan-cursus, zodat je dit in een nieuwe chat opnieuw kunt oppakken of uitbreiden.

**Laatste update:** september 2026 — met SRS-flashcard app en pealim-verificatie.

## Doel van het project

De cursus op **hebreway.com** wordt na afloop gewist. We hebben daarom alles offline gezet:

- 224 lessen (zinnen + audio + teacher notes) — periode 2 september 2025 t/m 14 juni 2026
- Bijlagen uit 2 WhatsApp-groepen (08-07-2025 en 02-09-2025) — 79 dagen aan notes
- Complete offline oefenomgeving met 19 HTML-apps
- 7793 woorden classificeerd per woordsoort (verbs / nouns / adjectives / etc.)
- 2.7 GB audio (2470 mp3's) van talmid, comics, expressions, hebrew cards
- Nieuwe **Flashcards Alef** app met SRS spaced repetition

Alles draait **100% offline**. Pealim-verificatie loopt via een apart script dat je op je laptop draait wanneer je online bent.

## Flashcards Alef — het hoofdstuk uit september 2026

`flashcards_alef.html` is een eigen SRS-flashcard app met:

- **SM-2 spaced repetition**: elke kaart krijgt een "volgende oefening"-datum, groeit bij goede antwoorden, krimpt bij fouten
- **Nieuwe kaarten per dag** limiet: 5 / 10 / 15 / 20 / 30 zelf instelbaar
- **HE↔EN in beide richtingen** (aparte schedules per richting)
- **4 knoppen**: ❌ Nee (morgen weer) / 🤔 Bijna (3 dagen) / ✅ Ja (langer) / ⭐ Beheerst (uit rotatie)
- **Undo** laatste beoordeling
- **Toggles**: nikud, fonetisch, voorbeeldzin, audio, Bijbels HE
- **Extra oefening** modus (telt NIET mee voor schedule) — kaarten die je vaak vergeet, vandaag's kaarten, alles
- **Zelf kaart toevoegen** + **deck importeren** (.json)
- **Backup export/restore** naar bestand
- **NL/EN taal-toggle**
- **Alles in localStorage** — 100% offline, geen account, geen server

Databronnen: `vocab_flash_data.js` (2018 kaarten uit lessen + notes), `phonetic_dict.js`, `verb_binyan_cache.js`, en later `pealim_verified.json` (na verify-run).

## Pealim.com verificatie

`pealim_verify.py` (dubbelklik `pealim_verify.bat`) checkt elke van je 199 unieke infinitieven tegen pealim.com voor:
- Correcte betekenis (EN)
- Correcte binyan
- Fonetiek in modern Israëlisch
- Root (3-4 letter wortel)

Resultaat komt in `pealim_verified.json`. Al gecachte woorden worden overgeslagen (incrementeel). 2 seconden vertraging tussen requests — nette scraping. Draai op je laptop, niet nodig voor de app zelf om te werken.

## Werkmap

```
C:\Users\User\Claude\ivriet docs\ulpan morasha alef 2025 2026\
```

Alle scripts en bestanden staan hier. Bij ophalen uit een nieuwe chat: laat Claude deze map als workspace selecteren.

## Belangrijkste eindbestanden

| Bestand | Wat het doet |
|---|---|
| `practice.html` | De offline oefenpagina (6 modes + woordenschat-tab) |
| `course_archive.html` | Dashboard met links naar alle lessen + teacher notes |
| `hebreway_backup.json` | De ruwe bundel met 202 lessen + 1817 audio-URLs |
| `vocabulary.html` | Losse woordenschatlijst (ook ingebed in practice.html) |
| `verbs_list.txt` | Gesorteerde lijst unieke infinitieven |
| `notes teacher\teachers_only\` | Bijlagen per docent gesorteerd |
| `notes teacher\by_date\` | Bijlagen per datum gesorteerd, met links naar lessen |

## Workflow (in volgorde)

### Stap 1 — Bundle ophalen uit hebreway

1. Log in op hebreway.com
2. Open de DevTools console (F12)
3. Plak en run `refresh_snippet.js`
4. Het script crawlt alle 202 lessen via de API en triggert een download van `hebreway_backup.json`
5. Sla het bestand op in de werkmap (overschrijft het oude)

**Vereiste vooraf:** In Chrome `chrome://settings/content/automaticDownloads` → hebreway.com toestaan om meerdere bestanden te downloaden.

### Stap 2 — MP3's uitpakken en downloaden

```powershell
.\setup_backup.ps1
```

Dit pakt de JSON uit, maakt een map per les, en downloadt alle MP3's (`-Force` overschrijft).

### Stap 3 — WhatsApp-bijlagen verwerken

Exporteer beide WhatsApp-groepen (`08.07.2025` en `02.09.2025`) als ZIP en zet die in `notes teacher\`.

```powershell
cd "notes teacher"
.\process_notes.ps1
.\organize_by_date.ps1
```

`process_notes.ps1` pakt de zips uit en groepeert bijlagen per afzender. `organize_by_date.ps1` maakt een tweede ordening per datum met cross-links naar hebreway-lessen.

### Stap 4 — PDF-tekst extraheren

```powershell
.\extract_pdf_text.ps1
```

Probeert in volgorde: Microsoft Word → pdftotext → Python (pdfplumber/PyPDF2) → Tesseract OCR (voor gescande PDF's). Schrijft naast elke `.pdf` een `.pdf.txt`.

### Stap 5 — OCR op whiteboard-foto's

Tesseract met Hebreeuws taalpakket moet geïnstalleerd zijn (`install_tesseract.ps1` doet dat automatisch via winget, of plaatst `heb.traineddata` in `C:\Users\User\Claude\tessdata`).

```powershell
.\extract_image_text.ps1
```

Schrijft naast elke afbeelding een `.image.txt` met de herkende Hebreeuwse tekst (verwacht ~50-70% accuracy bij handgeschreven whiteboards).

### Stap 6 — Woordenschat opbouwen

```powershell
.\build_vocabulary.ps1
```

Leest de JSON-bundel + alle `.docx`, `.pptx`, `.pdf.txt` en `.image.txt`, dedupliceert, classificeert per categorie, en schrijft `vocabulary.html` plus de ingebedde versie in `practice.html`.

### Stap 6b — Werkwoorden correct per binyan indelen (Pealim-scrape)

```powershell
.\extract_verbs.ps1        # genereert verbs_list.txt
.\scrape_pealim.ps1        # haalt voor elk werkwoord de echte binyan op
.\inline_binyan_cache.ps1  # plakt het resultaat in practice.html
```

Dit vervangt de heuristische binyan-indeling (`להת` = Hitpa'el, etc.) door echte data van pealim.com. Resultaat: `verb_binyan_cache.json`. Per werkwoord wordt ook bijgehouden in welke lessen het voorkomt (context). Eenmalige online-actie, daarna 100% offline. `scrape_pealim.ps1` heeft resume-support en kan opnieuw worden gestart na een crash.

### Stap 7 — Archief-overzicht genereren

```powershell
.\build_archive_html.ps1
```

Genereert `course_archive.html` met links naar alle lessen, MP3's en teacher notes.

### Alles in één keer

```powershell
.\refresh_all.ps1
```

Doet stap 2, 3, 4 en 7 achter elkaar (stap 1 moet je handmatig in de browser doen).

## practice.html — wat zit erin

### 7 oefenmodes (batch-view, zoals hebreway)

1. **TRANSLATIONS** — NL → HE
2. **LISTENING** — audio → kies juiste zin
3. **DICTATION** — audio → typ Hebreeuws
4. **BY TIME** — onder tijdsdruk
5. **PHANTOM** — woorden invullen
6. **VOICE** — uitspraak (Web Speech API, Hebreeuws, continuous=true, max 20s)
7. **Passieve listening** — alles achter elkaar afspelen

Elke regel heeft een eigen play-knop.

### Woordenschat-tab (hiërarchisch)

Drie hoofdgroepen, elk uitklapbaar met sub-groepen:

**WERKWOORDEN** (per binyan, alle 7):
- Pa'al / Pi'el (`ל` zonder `ה`)
- Nif'al (`להי` — jod direct na `לה`)
- Pu'al
- Hif'il (`לה` zonder directe jod, bijv. `להבין`, `להסביר`)
- Huf'al (`להו`)
- Hitpa'el (`להת`)
- Vervoegingen (niet-infinitieven)

**ZELFSTANDIGE NAAMWOORDEN** — per geslacht/aantal (m. ev., v. ev., m. mv., v. mv.)

**ANDERE WOORDSOORTEN** — 15 sub-groepen: voornaamwoorden per type, voorzetsels per type, telwoorden per type, bijwoorden, voegwoorden, etc.

Woorden kunnen in meerdere groepen tegelijk staan (multi-category membership).

Per groep een **flashcard-overlay** (K = ken ik, J = nog niet, Space = volgende).

Per werkwoord een **Pealim-link**: `https://www.pealim.com/dict/?search=<woord>` voor binyan-verificatie.

## Belangrijke technische beslissingen

- **Binyan-classificatie zonder nikud** is heuristisch op basis van het voorvoegsel van de infinitief. Geen perfecte oplossing — Hebreeuwse morfologie zonder echte NLP-bibliotheek is altijd benaderend.
- **Audio-URLs** uit hebreway zijn publiek leesbaar (S3 met public-read), dus downloaden werkt zonder login.
- **Pealim** wordt alleen als externe link gebruikt (geen scrape — bewust gekozen om niet afhankelijk te zijn van internet voor de rest).
- **Bundel-cache**: practice.html bewaart de bundle in localStorage. Knop "Bundle vernieuwen" leegt deze.
- **Niet-werkwoord blacklist** in `extract_verbs.ps1`: Hebreeuwse strings opgebouwd uit char-codes (`HebStr 0x05DC,...`) om encoding-problemen te vermijden. Bevat woorden als לא, לפעמים, לעבודה en conjugaties als לומד.

## Bekende beperkingen

- OCR op handschrift: ~50-70% accuracy, verwacht garbled woorden in de vocabulary
- Binyan-classificatie is heuristisch (zie boven)
- Web Speech API werkt alleen in Chrome/Edge
- File System Access API werkt niet op `file://` — practice.html moet vanaf disk geopend worden zonder server

## Setup vanaf nul (voor een nieuwe chat)

Als je in een nieuwe Claude-chat verder wilt:

1. Geef Claude toegang tot de map `C:\Users\User\Claude\ivriet docs\ulpan morasha alef 2025 2026`
2. Deel dit document (`PROJECT_OVERZICHT.md`)
3. Zeg: *"De bestanden en scripts staan al in de werkmap. Lees PROJECT_OVERZICHT.md en help me [X]."*

Voor een complete herbouw vanaf scratch heeft Claude nodig:
- Hebreway login (jij doet het inloggen)
- Beide WhatsApp-ZIP-exports in de werkmap
- Tesseract OCR (script installeert het)
- Microsoft Word óf Python met pdfplumber (voor PDF-extractie)

## Scripts in volgorde van afhankelijkheid

```
refresh_snippet.js              (browser, handmatig)
  └─ hebreway_backup.json
       └─ setup_backup.ps1
            └─ MP3's per les
       └─ extract_verbs.ps1
            └─ verbs_list.txt
       └─ build_vocabulary.ps1
            └─ vocabulary.html + practice.html (vocab-tab)

notes teacher/
  ├─ process_notes.ps1          (zips uitpakken, per zender)
  ├─ organize_by_date.ps1       (per datum, links naar lessen)
  ├─ extract_pdf_text.ps1       (PDF → .pdf.txt)
  ├─ extract_image_text.ps1     (whiteboard foto → .image.txt)
  └─ install_tesseract.ps1      (eenmalig)

refresh_all.ps1                 (orchestreert alles)
build_archive_html.ps1          (course_archive.html dashboard)
```

## Contact-mail

Mail van docent / cursus: nog niet meegenomen in de backup. Als je dat wilt toevoegen: exporteer de mail uit Gmail (via Takeout of als `.eml`) en laat een script bouwen dat per datum bij de juiste les koppelt.
