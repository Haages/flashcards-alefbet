// phonetic_dict.js
// Hardcoded fonetiek voor veelvoorkomende Hebreeuwse woorden waarvoor
// Pealim geen of foute uitspraak heeft.
// Plus een slimmere transliterate() die י en ו als klinkers herkent.
//
// Wordt geladen door practice.html via <script src="phonetic_dict.js"></script>
// en gebruikt door phoneticOf() als fallback voor PEALIM_CACHE.

window.COMMON_PHONETICS = {
  // ===== Getallen =====
  // Hoofdtelwoorden mannelijk
  "אחד":"echad", "שניים":"shnayim", "שלושה":"shlosha", "ארבעה":"arba'a",
  "חמישה":"chamisha", "שישה":"shisha", "שבעה":"shiv'a", "שמונה":"shmona",
  "תשעה":"tish'a", "עשרה":"asara",
  // Hoofdtelwoorden vrouwelijk
  "אחת":"achat", "שתיים":"shtayim", "שלוש":"shalosh", "ארבע":"arba",
  "חמש":"chamesh", "שש":"shesh", "שבע":"sheva", "שמונה":"shmone",
  "תשע":"tesha", "עשר":"eser",
  // Grote getallen
  "מאה":"me'a", "מאתיים":"matayim", "אלף":"elef", "אלפיים":"alpayim",
  "מיליון":"milyon", "מיליארד":"milyard",
  "עשרים":"esrim", "שלושים":"shloshim", "ארבעים":"arba'im",
  "חמישים":"chamishim", "שישים":"shishim", "שבעים":"shiv'im",
  "שמונים":"shmonim", "תשעים":"tish'im",
  // Rangtelwoorden
  "ראשון":"rishon", "שני":"sheni", "שלישי":"shlishi", "רביעי":"revi'i",
  "חמישי":"chamishi", "שישי":"shishi", "שביעי":"shvi'i", "שמיני":"shmini",
  "תשיעי":"tshi'i", "עשירי":"asiri",
  "ראשונה":"rishona", "שנייה":"shniya", "שלישית":"shlishit", "רביעית":"revi'it",

  // ===== Persoonlijke voornaamwoorden =====
  "אני":"ani", "אתה":"ata", "את":"at", "הוא":"hu", "היא":"hi",
  "אנחנו":"anachnu", "אתם":"atem", "אתן":"aten", "הם":"hem", "הן":"hen",
  // Object
  "אותי":"oti", "אותך":"otcha", "אותו":"oto", "אותה":"ota",
  "אותנו":"otanu", "אתכם":"etchem", "אתכן":"etchen", "אותם":"otam", "אותן":"otan",
  // Bezittelijk
  "שלי":"sheli", "שלך":"shelcha", "שלו":"shelo", "שלה":"shela",
  "שלנו":"shelanu", "שלכם":"shelachem", "שלכן":"shelachen", "שלהם":"shelahem", "שלהן":"shelahen",
  // Aanwijzend
  "זה":"ze", "זאת":"zot", "זו":"zo", "אלה":"ele", "אלו":"elu",

  // ===== Vraagwoorden =====
  "מי":"mi", "מה":"ma", "איפה":"eyfo", "איך":"eich", "למה":"lama",
  "מדוע":"madua", "מתי":"matai", "כמה":"kama", "איזה":"eize", "איזו":"eizo",
  "לאן":"le'an", "מאיפה":"me'eyfo", "מאין":"me'ayin",

  // ===== Voorzetsels =====
  "של":"shel", "על":"al", "עם":"im", "אל":"el", "מן":"min",
  "ב":"be", "ל":"le", "מ":"me", "ה":"ha", "ו":"ve", "ש":"she",
  "אצל":"etzel", "לפני":"lifnei", "אחרי":"acharei", "בין":"bein",
  "תחת":"tachat", "מתחת":"mitachat", "מעל":"me'al", "ליד":"leyad",
  "מול":"mul", "סביב":"saviv", "כמו":"kmo", "בלי":"bli", "ללא":"lelo",
  "בלעדי":"bil'adei", "נגד":"neged", "בעד":"be'ad", "לפי":"lefi",
  "עד":"ad", "מאז":"me'az", "כדי":"kdei", "בגלל":"biglal", "למרות":"lamrot",
  "כי":"ki", "אם":"im", "אבל":"aval", "אך":"ach", "או":"o",
  "וגם":"vegam", "גם":"gam", "רק":"rak", "כמעט":"kim'at", "כבר":"kvar",
  "עוד":"od", "עכשיו":"achshav", "אז":"az", "תמיד":"tamid", "אף פעם":"af pa'am",
  "אולי":"ulai", "כן":"ken", "לא":"lo", "אין":"ein", "יש":"yesh",

  // ===== Tijd =====
  "יום":"yom", "שבוע":"shavua", "חודש":"chodesh", "שנה":"shana",
  "בוקר":"boker", "צהריים":"tzohorayim", "ערב":"erev", "לילה":"laila",
  "אתמול":"etmol", "היום":"hayom", "מחר":"machar", "מחרתיים":"machratayim",
  "השבוע":"hashavua", "השנה":"hashana",
  "ראשון":"rishon", "שני":"sheni", "שלישי":"shlishi", "רביעי":"revi'i",
  "חמישי":"chamishi", "שישי":"shishi", "שבת":"shabat",
  "ינואר":"yanuar", "פברואר":"februar", "מרץ":"merts", "אפריל":"april",
  "מאי":"mai", "יוני":"yuni", "יולי":"yuli", "אוגוסט":"ogust",
  "ספטמבר":"september", "אוקטובר":"oktober", "נובמבר":"november", "דצמבר":"detsember",

  // ===== Plaats =====
  "פה":"po", "כאן":"kan", "שם":"sham", "אן":"an",
  "בית":"bait", "הבית":"habait", "הביתה":"habayta",
  "ישראל":"yisrael", "ירושלים":"yerushalayim", "תל אביב":"tel aviv",
  "חיפה":"chaifa", "אילת":"eilat", "באר שבע":"be'er sheva",

  // ===== Familie =====
  "אבא":"aba", "אמא":"ima", "בן":"ben", "בת":"bat", "אח":"ach", "אחות":"achot",
  "סבא":"saba", "סבתא":"savta", "דוד":"dod", "דודה":"doda",
  "אשה":"isha", "איש":"ish", "ילד":"yeled", "ילדה":"yalda", "ילדים":"yeladim",

  // ===== Veelvoorkomende werkwoord-infinitieven =====
  "להיות":"lihiot", "ללכת":"lalechet", "לבוא":"lavo", "לראות":"lirot",
  "לשמוע":"lishmoa", "לדבר":"ledaber", "לאכול":"le'echol", "לשתות":"lishtot",
  "לישון":"lishon", "לקום":"lakum", "לעבוד":"la'avod", "לכתוב":"lichtov",
  "לקרוא":"likro", "ללמוד":"lilmod", "לעשות":"la'asot", "לתת":"latet",
  "לקחת":"lakachat", "לקנות":"liknot", "למכור":"limkor", "לשאול":"lish'ol",
  "לענות":"la'anot", "להבין":"lehavin", "לחשוב":"lachshov", "לזכור":"lizkor",
  "לשכוח":"lishkoach", "לאהוב":"le'ehov", "לרצות":"lirtzot", "ליצור":"litzor",
  "לשלם":"leshalem", "להזמין":"lehazmin", "לבטל":"levatel", "לתקן":"letaken",
  "לסדר":"lesader", "לחפש":"lechapes", "לעלות":"la'alot", "לטעות":"lit'ot",
  "לקרות":"likrot", "לפנות":"lifnot", "לשתות":"lishtot", "להזיז":"lehaziz",
  "להחזיר":"lehachzir", "להסביר":"lehasbir", "לעזור":"la'azor", "להראות":"lehar'ot",
  "להגיד":"lehagid", "להתקשר":"lehitkasher", "לטייל":"letayel", "להישאר":"lehisha'er",
  "להתחיל":"lehatchil", "לפתוח":"liftoach", "לסגור":"lisgor", "להוציא":"lehotzi",
  "להכניס":"lehachnis", "להגיע":"lehagi'a", "לעבור":"la'avor", "לנסוע":"linso'a",
  "לרוץ":"larutz", "ללבוש":"lilbosh", "להוריד":"lehorid", "להעלות":"leha'alot",

  // ===== Veelvoorkomende zelfstandige naamwoorden =====
  "כסף":"kesef", "זמן":"zman", "אוכל":"ochel", "מים":"mayim", "לחם":"lechem",
  "עבודה":"avoda", "ספר":"sefer", "עט":"et", "עט":"et",
  "מילה":"mila", "שאלה":"she'ela", "תשובה":"tshuva",
  "טוב":"tov", "רע":"ra", "יפה":"yafe", "קשה":"kashe", "קל":"kal",
  "גדול":"gadol", "קטן":"katan", "חדש":"chadash", "ישן":"yashan",
  "טעות":"ta'ut", "דירה":"dira", "חבר":"chaver", "חברה":"chavera",

  // ===== Begroetingen / dagelijks =====
  "שלום":"shalom", "תודה":"toda", "בבקשה":"bevakasha", "סליחה":"slicha",
  "מה שלומך":"ma shlomcha", "מה נשמע":"ma nishma",
  "בוקר טוב":"boker tov", "ערב טוב":"erev tov", "לילה טוב":"laila tov",
  "להתראות":"lehitra'ot", "ביי":"bay",

  // ===== Doubt + against extra =====
  "ספק":"safek", "בספק":"besafek", "ודאי":"vadai",
};

// Improved transliterate: handles י and ו as vowels (mater lectionis)
// when context suggests they're not consonants.
window.transliterate = function(heb) {
  if (!heb) return '';
  // Strip nikud + geresh/gershayim
  const clean = heb.replace(/[֑-ׇ׳״]/g, '');
  if (!clean) return '';
  // Check dictionary first
  if (window.COMMON_PHONETICS && window.COMMON_PHONETICS[clean]) return window.COMMON_PHONETICS[clean];

  const HEB_LATIN = {
    'א':'', 'ב':'v', 'ג':'g', 'ד':'d', 'ה':'h', 'ו':'v', 'ז':'z',
    'ח':'ch', 'ט':'t', 'י':'y', 'כ':'kh', 'ך':'kh', 'ל':'l', 'מ':'m',
    'ם':'m', 'נ':'n', 'ן':'n', 'ס':'s', 'ע':'', 'פ':'f', 'ף':'f',
    'צ':'ts', 'ץ':'ts', 'ק':'k', 'ר':'r', 'ש':'sh', 'ת':'t'
  };

  const len = clean.length;
  let out = '';
  for (let i = 0; i < len; i++) {
    const c = clean[i];
    const prev = i > 0 ? clean[i-1] : null;
    const next = i < len - 1 ? clean[i+1] : null;

    // Letter-positie heuristieken
    if (c === 'א') {
      // א aan begin: meestal 'a' of 'e'
      if (i === 0) out += 'a';
      // א in midden of einde: meestal stil, met klinker ervoor
      else if (out && !/[aeiou]/.test(out.slice(-1))) out += 'a';
    } else if (c === 'ע') {
      // ע ongeveer als א
      if (i === 0) out += 'a';
      else if (out && !/[aeiou]/.test(out.slice(-1))) out += 'a';
    } else if (c === 'ה') {
      // ה aan einde: meestal stil of 'a'
      if (i === len - 1) {
        if (out && !/[aeiou]/.test(out.slice(-1))) out += 'a';
      } else if (i === 0) {
        out += 'ha';
      } else {
        out += 'h';
      }
    } else if (c === 'י') {
      // י aan begin: 'y' + 'i' of 'a' afhankelijk volgende
      if (i === 0) out += 'y';
      // י na een medeklinker, of als mater lectionis: 'i'
      else if (out && !/[aeiou]/.test(out.slice(-1))) out += 'i';
      // י tussen klinkers: 'y'
      else out += 'y';
    } else if (c === 'ו') {
      // ו aan begin: 'v' of 've'
      if (i === 0) {
        out += 've';
      } else if (next === 'ו') {
        out += 'u';
      } else if (prev === 'ו') {
        // tweede ו van ww: 'u'
        // already handled
      } else if (out && !/[aeiou]/.test(out.slice(-1))) {
        // ו tussen 2 medeklinkers: 'o' (closed syl) of 'u' — kies 'o'
        out += 'o';
      } else {
        out += 'v';
      }
    } else if (c in HEB_LATIN) {
      // Voor andere medeklinker: voeg eerst klinker toe als nodig
      if (out && i > 0 && !/[aeiou]/.test(out.slice(-1))
          && prev && prev !== 'א' && prev !== 'ע' && prev !== 'ה'
          && prev !== 'י' && prev !== 'ו') {
        out += 'e'; // schwa-equivalent
      }
      out += HEB_LATIN[c];
    } else if (/[֐-׿]/.test(c)) {
      // overige Hebreeuwse tekens: weglaten
    } else {
      out += c;
    }
  }
  return out;
};
