# Voegwoorden — Ulpan Morasha Alef 2025/2026

© 2026 Jessica Haages · 7 woorden

| # | Hebreeuws | Fonetiek | Engels |
|---|---|---|---|
| 1 | אבל | — |  |
| 2 | או | — |  |
| 3 | אם | — |  |
| 4 | בזמן | — |  |
| 5 | כי | — |  |
| 6 | לכן | — |  |
| 7 | למרות | — |  |