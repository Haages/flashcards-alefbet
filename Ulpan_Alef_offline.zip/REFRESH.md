# How to refresh your backup (when new lessons appear)

Your course is still running and new lessons keep arriving. To pull
them into your local backup, do this whenever you want to catch up:

## 1. Re-crawl hebreway in your browser

1. Open Chrome and go to **https://hebreway.com/home** (log in if needed —
   you should see your list of lessons).
2. Press **F12** to open DevTools.
3. Click the **Console** tab at the top of DevTools.
4. The first time you do this, Chrome may show a warning that says
   *"Don't paste code you don't understand"*. Type
   **`allow pasting`** and press Enter to dismiss it.
5. Open **`refresh_snippet.js`** (this folder) in Notepad,
   select all (Ctrl+A), copy (Ctrl+C), and paste into the Console (Ctrl+V),
   then press Enter.
6. Wait ~15 seconds. You'll see messages like:
   ```
   Found 210 lessons. Fetching details...
   Got all lesson details. Building bundle...
   ✓ Downloaded hebreway_backup.json (212 files, 1850 audio URLs)
   ```
7. Chrome will save a new **`hebreway_backup.json`** to your Downloads folder.

## 2. Re-run the setup script with -Force

Open PowerShell in this folder and run:

```powershell
.\setup_backup.ps1 -Force
```

The script will:
- Auto-move the new `hebreway_backup.json` from Downloads (it's newer, so it wins).
- Overwrite existing lesson markdown files with the refreshed content
  (because of `-Force`). New lessons are added.
- Download only the audio files that aren't already on disk. Existing
  audio is left alone, so this is fast — usually just the few new MP3s
  from the new lessons.

Without `-Force`, the script only ADDS new lessons; existing files are left
unchanged. Use `-Force` when you want to refresh content the teacher may
have edited or corrected.

## Quick checklist

- New lessons in your course? → Run `refresh_snippet.js`, then
  `.\setup_backup.ps1 -Force`.
- Just want to retry a failed audio download? → Run `.\setup_backup.ps1`
  (no `-Force` needed).
- Need to reset your practice progress (the known/seen marks in
  `practice.html`)? → Open `practice.html` and click the **Reset progress**
  button.

## Troubleshooting

- **"Multiple downloads blocked" in Chrome:** Go to
  `chrome://settings/content/automaticDownloads`, add `hebreway.com` to
  Allowed. You already did this once; it should still be allowed.
- **Console says "allow pasting" but you can't type it:** click into the
  Console area first to give it focus, then type `allow pasting` and Enter.
- **Got an error about cookies or 401/403:** make sure you're logged into
  hebreway.com in the same Chrome window where DevTools is open.
