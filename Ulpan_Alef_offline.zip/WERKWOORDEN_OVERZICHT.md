# Werkwoorden overzicht — Ulpan Morasha Alef 2025/2026

© 2026 Jessica Haages · Bijgewerkt: 2026-09-13 · 202 infinitieven

Fonetiek: `/vast/` = pealim-verified · `~gok~` = auto-transliteratie uit nikud. Draai `pealim_verify.bat` voor 100% verified.

| # | Werkwoord | Fonetiek | Engels | Binyan |
|---|---|---|---|---|
| 1 | יכול | ~yaol~ | to be able | פעל |
| 2 | לאהוב | /le'ehov/ | to like, to love | פעל |
| 3 | לאחל | ~leachel~ | to wish | פיעל |
| 4 | לאחר | /le'acher/ | to be late | פיעל |
| 5 | לאכול | /le'echol/ | to eat | פעל |
| 6 | לאסור | ~leesor~ | to forbid, to prohibit | פעל |
| 7 | לאפשר | ~leafsher~ | to enable, to permit, to allow | פיעל |
| 8 | לבדוק | /livdok/ | to check | פעל |
| 9 | לבוא | /lavo/ | to come | פעל |
| 10 | לבטל | /levatel/ | to cancel | פיעל |
| 11 | לבלות | ~levalot~ | to have a good time | פיעל |
| 12 | לבנות | ~livnot~ | to build | פעל |
| 13 | לבקר | /levaker/ | to criticize | פיעל |
| 14 | לבקש | /levakesh/ | to request, to ask to do something | פיעל |
| 15 | לברוח | /livroach/ | to escape, to run away | פעל |
| 16 | לברר | /levarer/ | to inquire, to find out, to clarify | פיעל |
| 17 | לבשל | /levashel/ | to cook | פיעל |
| 18 | לגור | /lagur/ | to live | פעל |
| 19 | לגמור | /ligmor/ | to finish | פעל |
| 20 | לדאוג | /lid'og/ | to worry | פעל |
| 21 | לדבר | /ledaber/ | to speak | פיעל |
| 22 | לדחוף | ~lidchof~ | to push | פעל |
| 23 | לדעת | /lada'at/ | to know | פעל |
| 24 | להאמין | /leha'amin/ | to believe  | הפעיל |
| 25 | להבטיח | /lehavtiach/ | to promise | הפעיל |
| 26 | להביא | /lehavi/ | to bring | הפעיל |
| 27 | להבין | /lehavin/ | to understand | הפעיל |
| 28 | להגיד | /lehagid/ | to say, to tell | הפעיל |
| 29 | להגיע | /lehagia/ | to arrive, to get to, to reach | הפעיל |
| 30 | להגשים | ~lehagshim~ | to make a dream come true, to fulfill a dream | הפעיל |
| 31 | להדליק | /lehadlik/ | to turn on | הפעיל |
| 32 | להודות | ~lehodot~ | To thank | הפעיל |
| 33 | להודיע | ~lehodia~ | to let know, to inform, to announce | הפעיל |
| 34 | להוציא | ~lehotsi~ | to take out | הפעיל |
| 35 | להוריד | ~lehorid~ | to take down | הפעיל |
| 36 | להזכיר | /lehazkir/ | to remind | הפעיל |
| 37 | להזמין | /lehazmin/ | to invite | הפעיל |
| 38 | להחזיק | /lehachzik/ | to hold | הפעיל |
| 39 | להחזיר | /lehachazir/ | to return something, to give back | הפעיל |
| 40 | להחליט | /lehachlit/ | to decide | הפעיל |
| 41 | להחליף | /lehachalif/ | to exchange | הפעיל |
| 42 | להיגמר | /lehigamer/ | to be finished, to end | נפעל |
| 43 | להיוולד | ~lehivaled~ | to be born | נפעל |
| 44 | להיות | /lihyot/ | to be | פעל |
| 45 | להיכנס | /lehikanes/ | to enter, to come in | נפעל |
| 46 | להיסגר | /lehisager/ | to be closed | נפעל |
| 47 | להיפגש | /lehipagesh/ | to meet | נפעל |
| 48 | להישאר | /lehisha'er/ | to stay | נפעל |
| 49 | להכין | /lehachin/ | to prepare | הפעיל |
| 50 | להכיר | /lehakir/ | to be acquainted with someone, to know someone, to be familiar with something | הפעיל |
| 51 | להכניס | ~lehanis~ | to put in, to bring in, to insert | הפעיל |
| 52 | להמליץ | /lehamlitz/ | to recommend | הפעיל |
| 53 | להמריא | ~lehamri~ | to take off | הפעיל |
| 54 | להמשיך | /lehamshich/ | to continue | הפעיל |
| 55 | להסביר | /lehasbir/ | to explain | הפעיל |
| 56 | להסכים | /lehaskim/ | to agree | הפעיל |
| 57 | להספיק | ~lehaspik~ | to succeed in doing something on time | הפעיל |
| 58 | להסתדר | /lehistader/ | to manage | התפעל |
| 59 | להסתכל | ~lehistael~ | to look | התפעל |
| 60 | להעביר | /leha'avir/ | to pass something, to transfer | הפעיל |
| 61 | להעדיף | /leha'adif/ | to prefer | הפעיל |
| 62 | להעריך | /leha'arich/ | to appreciate | הפעיל |
| 63 | להפסיק | /lehafsik/ | to stop | הפעיל |
| 64 | להפעיל | ~lehafil~ | to activate | הפעיל |
| 65 | להפריע | /lehafria/ | to disturb, to bother, to interrupt | הפעיל |
| 66 | להצטער | ~lehitstaer~ | to be sorry, to regret | התפעל |
| 67 | להציל | /lehatzil/ | to save, to rescue, to salvage | הפעיל |
| 68 | להצליח | /lehatzliach/ | to succeed, to manage to do something | הפעיל |
| 69 | להקשיב | /lehakshiv/ | to listen | הפעיל |
| 70 | להראות | /lehar'ot/ | to show | הפעיל |
| 71 | להרגיש | /lehargish/ | to feel , to sense | הפעיל |
| 72 | להרים | /leharim/ |  | הפעיל |
| 73 | להרשות | /leharshot/ | to allow | הפעיל |
| 74 | להשאיר | ~lehashir~ | to leave something  | הפעיל |
| 75 | להשתדל | /lehishtadel/ | to do your best | התפעל |
| 76 | להשתמש | /lehishtamesh/ | to use | התפעל |
| 77 | להשתנות | /lehishtanot/ | to change (oneself), to become different | התפעל |
| 78 | להשתתף | ~lehishtatef~ | to participate | התפעל |
| 79 | להתאים | ~lehatim~ | to suit | הפעיל |
| 80 | להתחיל | /lehatchil/ | to start, to begin | הפעיל |
| 81 | להתכוון | /lehitkaven/ | to intend, to mean | התפעל |
| 82 | להתלונן | /lehitlonen/ | to complain | התפעל |
| 83 | להתנצל | ~lehitnatsel~ | to apologize | התפעל |
| 84 | להתעורר | /lehit'orer/ | to wake up | התפעל |
| 85 | להתפלל | /lehitpalel/ | to pray | התפעל |
| 86 | להתפעל | ~lehitpael~ | to be impressed | התפעל |
| 87 | להתקדם | /lehitkadem/ | to progress, to advance | התפעל |
| 88 | להתקיים | /lehitkayem/ | to take place | התפעל |
| 89 | להתקשר | /lehitkasher/ | to call, to phone | התפעל |
| 90 | להתרגל | /lehitragel/ | to get used to | התפעל |
| 91 | לומר | /lomar/ | to say, to tell | פעל |
| 92 | לזכור | /lizkor/ | to remember, to keep in mind | פעל |
| 93 | לחבר | /lechaber/ | to connect | פיעל |
| 94 | לחדש | ~lechadesh~ | to renew | פיעל |
| 95 | לחזור | /lachazor/ | to return | פעל |
| 96 | לחזק | ~lechazek~ | to strengthen, to reinforce, to give strength | פיעל |
| 97 | לחיות | ~lichiot~ | to live | פעל |
| 98 | לחייב | ~lechayev~ | to obligate, to force | פיעל |
| 99 | לחכות | /lechakot/ | to wait | פיעל |
| 100 | לחלום | /lachlom/ | to dream | פעל |
| 101 | לחלות | ~lachlot~ | to become ill | פעל |
| 102 | לחלק | ~lechalek~ | to divide, to split | פיעל |
| 103 | לחפש | /lechapes/ | to search, to look for | פיעל |
| 104 | לחשוב | /lachshov/ | to think | פעל |
| 105 | לחתום | /lachtom/ | to sign | פעל |
| 106 | לטוס | ~latus~ | to fly | פעל |
| 107 | לטייל | /letayel/ | to take a trip, to travel | פיעל |
| 108 | לטעות | /lit'ot/ | to be wrong, to make a mistake | פעל |
| 109 | לטפל | /letapel/ | to take care of, to treat | פיעל |
| 110 | לישון | /lishon/ | to sleep | פעל |
| 111 | לכאוב | ~liov~ | to feel pain, to ache, to hurt | פעל |
| 112 | לכלול | ~lilol~ | to include | פעל |
| 113 | לכתוב | /lichtov/ | to write | פעל |
| 114 | ללחוץ | /lilchotz/ | to press | פעל |
| 115 | ללכת | /lalechet/ | to go | פעל |
| 116 | ללמד | ~lelamed~ | to teach | פיעל |
| 117 | ללמוד | /lilmod/ | to learn, to study | פעל |
| 118 | למדוד | /lamod/ | to measure | פעל |
| 119 | למהר | ~lemaher~ | to hurry up, to be in a hurry | פיעל |
| 120 | למות | ~lamut~ | to die | פעל |
| 121 | למכור | /limkor/ | to sell | פעל |
| 122 | למלא | /lemale/ | to fill | פיעל |
| 123 | למצוא | /limtzo/ | to find | פעל |
| 124 | לנוח | /lanuach/ | to rest | פעל |
| 125 | לנסוע | /linsoa/ | to travel | פעל |
| 126 | לנסות | /lenasot/ | to try | פיעל |
| 127 | לנתק | /lenatek/ | to disconnect | פיעל |
| 128 | לסגור | /lisgor/ | to close | פעל |
| 129 | לסדר | /lesader/ | to arrange, to put in order | פיעל |
| 130 | לסיים | /lesayem/ | to finish | פיעל |
| 131 | לסמוך | /lismoch/ | to rely, to count on | פעל |
| 132 | לספור | ~lispor~ | to count | פעל |
| 133 | לספר | /lesaper/ | to tell a story, a joke | פיעל |
| 134 | לעבוד | /la'avod/ | to work | פעל |
| 135 | לעבור | /la'avor/ | to pass | פעל |
| 136 | לעזוב | /la'azov/ | to leave (a place) | פעל |
| 137 | לעזור | /la'azor/ | to help | פעל |
| 138 | לעלות | /la'alot/ | to go up | פעל |
| 139 | לעמוד | /la'amod/ | to stand | פעל |
| 140 | לענות | /la'anot/ | to answer | פעל |
| 141 | לעסוק | ~laasok~ | to work at | פעל |
| 142 | לעשות | /la'asot/ | to do | פעל |
| 143 | לעשן | /le'ashen/ | to smoke | פיעל |
| 144 | לפגוש | ~lifgosh~ | to encounter, to meet, to run into someone | פעל |
| 145 | לפחוד | /lifchod/ | to be afraid | פעל |
| 146 | לפנות | /lifnot/ | to clear  | פיעל |
| 147 | לפרסם | /lefarsem/ | to publish, to publicize, to advertise | פיעל |
| 148 | לפתוח | /liftoach/ | to open | פעל |
| 149 | לצאת | /latzet/ | to go out | פעל |
| 150 | לצחוק | /litzchok/ | to laugh | פעל |
| 151 | לצעוק | /litz'ok/ | to shout | פעל |
| 152 | לקבוע | /likboa/ | to schedule, to set up | פעל |
| 153 | לקבל | /lekabel/ | to receive, to get | פיעל |
| 154 | לקוות | ~lekauot~ | to hope | פיעל |
| 155 | לקום | /lakum/ | to get up | פעל |
| 156 | לקחת | /lakachat/ | to take | פעל |
| 157 | לקיים | /lekayem/ |  | פיעל |
| 158 | לקלקל | /lekalkel/ | to spoil, to damage | פיעל |
| 159 | לקנות | /liknot/ | to buy | פעל |
| 160 | לקצר | ~lekatser~ | to shorten | פיעל |
| 161 | לקרוא | /likro/ | to read | פעל |
| 162 | לקרות | /lekarot/ | to happen | פעל |
| 163 | לראות | /lir'ot/ | to see | פעל |
| 164 | לרדת | /laredet/ | to go down, to descend | פעל |
| 165 | לרוץ | ~laruts~ | to run | פעל |
| 166 | לרצות | ~lirtsot~ |  | פיעל |
| 167 | לרשום | /lirshom/ | to register | פעל |
| 168 | לשאול | /lish'ol/ | to borrow | פעל |
| 169 | לשבת | /lashevet/ | to sit | פעל |
| 170 | לשים | /lasim/ | to put | פעל |
| 171 | לשיר | ~lashir~ | to sing | פעל |
| 172 | לשכוח | /lishkoach/ | to forget | פעל |
| 173 | לשכור | /liskor/ | to rent | פעל |
| 174 | לשלוח | /lishloach/ | to send | פעל |
| 175 | לשלם | /leshalem/ | to pay | פיעל |
| 176 | לשמוח | /lismoach/ | to be happy | פעל |
| 177 | לשמוע | /lishmoa/ | to hear | פעל |
| 178 | לשמור | /lishmor/ | to guard | פעל |
| 179 | לשנות | /lishnot/ | to change (something) | פיעל |
| 180 | לשקול | /lishkol/ | to weigh | פעל |
| 181 | לשרת | ~lesharet~ | to serve (clients) | פיעל |
| 182 | לשתות | /lishtot/ | to drink | פעל |
| 183 | לתלות | ~litlot~ | to hang | פעל |
| 184 | לתפוס | /litpos/ | to catch | פעל |
| 185 | לתקן | /letaken/ | to fix, to repair | פיעל |
| 186 | לתת | ~latet~ | to give | פעל |
| 187 | מאוחר | ~meuchar~ | late | פועל |
| 188 | מבוטל | ~mevutal~ | is canceled | פועל |
| 189 | מבושל | ~mevushal~ | is cooked | פועל |
| 190 | מובן | ~muvan~ | is understood | הופעל |
| 191 | מוזמן | ~muzman~ | is invited  | הופעל |
| 192 | מוכן | ~muan~ | is prepared, ready | הופעל |
| 193 | מומלץ | ~mumlats~ |  is recommended | הופעל |
| 194 | מוקדם | ~mukdam~ | is rescheduled to an earlier time | הופעל |
| 195 | מחובר | ~mechubar~ | is connected | פועל |
| 196 | מטופל | ~metupal~ | is being taken care of, is being cared for | פועל |
| 197 | מנותק | ~menutak~ | is disconnected, cut off | פועל |
| 198 | מסודר | ~mesudar~ | is put in order, is tidied, is arranged, is settled, is taken care of | פועל |
| 199 | מפורסם | ~mefursam~ | is published, is publicized, is advertised | פועל |
| 200 | מקובל | ~mekubal~ | acceptable | פועל |
| 201 | מקולקל | ~mekulkal~ | spoiled, broken, out of order | פועל |
| 202 | צריך | ~tsari~ | need (future tense is used in infinitive to need לְהִצְטָרֵךְ) | פעל |