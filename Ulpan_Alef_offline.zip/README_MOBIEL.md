# Ulpan Alef — Complete pakket voor je telefoon

**14 MB · 100% offline · geen internet nodig na uitpakken**

## Zet op je iPhone

1. Download `Ulpan_Alef_offline.zip` op je telefoon (via mail, WhatsApp of AirDrop)
2. Open **Files** (Bestanden) app
3. Tik lang op het ZIP-bestand → **Uitpakken**
4. Open de map en tik `index.html`
5. Safari opent het dashboard met alle apps
6. Voor snelle toegang: deel → **Zet op beginscherm**

## Zet op Android

Zelfde als hierboven maar met Chrome + Google Files-app.

## Wat zit erin

- 20+ oefen-apps (practice, vocabulary, comics, expressions, ...)
- Alle woordenschat-databases (7400+ woorden)
- 542 werkwoord-vervoegingen
- 224 lessen bundel
- 490 uitdrukkingen
- Overzicht-documenten per woordsoort

## Wat NIET erin zit

- Audio-bestanden (2.7 GB — te groot voor telefoon)
- Teacher notes bijlagen (1.3 GB — privé)

Voor audio + teacher notes: op je laptop.

© 2026 Jessica Haages — Alle rechten voorbehouden
