// plurals_dict.js
// Hebreeuwse meervouden + geslacht voor veelvoorkomende zelfstandige naamwoorden.
// Gebaseerd op:
//   - extra spelling etc/Adobe Scan 03 feb 2026.pdf  (meervouden-oefening)
//   - extra spelling etc/Adobe Scan 31 mei 2026.pdf  (יוצאי דופן + רבים וסמיכות)
//   - algemene Hebreeuwse woordenschat Morasha Alef
//
// Format per woord:
//   "singular": { p: "plural", g: "m"|"f"|"mf", note?: "optional info" }
//
// Wordt geladen door practice.html via <script src="plurals_dict.js"></script>.

window.PLURALS_DICT = {
  // Mannelijk regelmatig (sg → -ים)
  "אב": { p:"אבות", g:"m", irreg:"m_otot", note:"onregelmatig (-ות)" , smichut:{ssg:"אבי", spl:"אבות"} },
  "אח": { p:"אחים", g:"m" },
  "אדון": { p:"אדונים", g:"m" },
  "אזרח": { p:"אזרחים", g:"m" },
  "גן": { p:"גנים", g:"m" },
  "דג": { p:"דגים", g:"m" },
  "דוד": { p:"דודים", g:"m" },
  "חבר": { p:"חברים", g:"m" , smichut:{ssg:"חבר", spl:"חברי"} },
  "חלום": { p:"חלומות", g:"m", irreg:"m_otot", note:"onregelmatig (-ות)" },
  "חתול": { p:"חתולים", g:"m" , smichut:{ssg:"חתול", spl:"חתולי"} },
  "ילד": { p:"ילדים", g:"m" , smichut:{ssg:"ילד", spl:"ילדי"} },
  "כלב": { p:"כלבים", g:"m" , smichut:{ssg:"כלב", spl:"כלבי"} },
  "לוח": { p:"לוחות", g:"m", irreg:"m_otot", note:"onregelmatig (-ות)" },
  "לילה": { p:"לילות", g:"m", irreg:"m_otot", note:"m. ondanks -ה" },
  "מורה": { p:"מורים", g:"m" },
  "סוס": { p:"סוסים", g:"m" , smichut:{ssg:"סוס", spl:"סוסי"} },
  "סוף": { p:"סופים", g:"m" },
  "סנדל": { p:"סנדלים", g:"m" },
  "ספר": { p:"ספרים", g:"m" , smichut:{ssg:"ספר", spl:"ספרי"} },
  "עיתון": { p:"עיתונים", g:"m" },
  "פסל": { p:"פסלים", g:"m" },
  "סוד": { p:"סודות", g:"m", irreg:"m_otot", note:"onregelmatig (-ות)" },
  "תמרור": { p:"תמרורים", g:"m" },
  "כיסא": { p:"כיסאות", g:"m", irreg:"m_otot", note:"onregelmatig (-ות)" },
  "כלל": { p:"כללים", g:"m" },
  "מקום": { p:"מקומות", g:"m", irreg:"m_otot", note:"onregelmatig (-ות)" , smichut:{ssg:"מקום", spl:"מקומות"} },
  "ספור": { p:"ספורים", g:"m" },
  "שיר": { p:"שירים", g:"m" },
  "שולחן": { p:"שולחנות", g:"m", irreg:"m_otot", note:"onregelmatig (-ות)" , smichut:{ssg:"שולחן", spl:"שולחנות"} },
  "חדר": { p:"חדרים", g:"m" },
  "קיר": { p:"קירות", g:"m", irreg:"m_otot", note:"onregelmatig (-ות)" },
  "חוט": { p:"חוטים", g:"m" },
  "כביש": { p:"כבישים", g:"m" },
  "ים": { p:"ימים", g:"m" },
  "יום": { p:"ימים", g:"m", note:"onregelmatig stam" , smichut:{ssg:"יום", spl:"ימי"} },
  "גזל": { p:"גזלים", g:"m" },
  "חיל": { p:"חילים", g:"m" },
  "אזרח": { p:"אזרחים", g:"m" },

  // Vrouwelijk regelmatig (sg op -ה of -ת → -ות)
  "אישה": { p:"נשים", g:"f", irreg:"f_im", note:"sterk onregelmatig" , smichut:{ssg:"אשת", spl:"נשות"} },
  "מילה": { p:"מילים", g:"f", irreg:"f_im", note:"-ים ondanks vrouwelijk" , smichut:{ssg:"מילת", spl:"מילי"} },
  "אזרחית": { p:"אזרחיות", g:"f" },
  "ארץ": { p:"ארצות", g:"f", note:"sterk onregelmatig" , smichut:{ssg:"ארץ", spl:"ארצות"} },
  "דרך": { p:"דרכים", g:"f", irreg:"f_im", note:"-ים ondanks vrouwelijk" , smichut:{ssg:"דרך", spl:"דרכי"} },
  "עיר": { p:"ערים", g:"f", irreg:"f_im", note:"-ים ondanks vrouwelijk" , smichut:{ssg:"עיר", spl:"ערי"} },
  "שנה": { p:"שנים", g:"f", irreg:"f_im", note:"-ים ondanks vrouwelijk" , smichut:{ssg:"שנת", spl:"שנות"} },
  "שעה": { p:"שעות", g:"f" , smichut:{ssg:"שעת", spl:"שעות"} },
  "דקה": { p:"דקות", g:"f" , smichut:{ssg:"דקת", spl:"דקות"} },
  "דלת": { p:"דלתות", g:"f" , smichut:{ssg:"דלת", spl:"דלתות"} },
  "חולצה": { p:"חולצות", g:"f" },
  "כיתה": { p:"כיתות", g:"f" , smichut:{ssg:"כיתת", spl:"כיתות"} },
  "מיטה": { p:"מיטות", g:"f" },
  "מכונית": { p:"מכוניות", g:"f" },
  "משפחה": { p:"משפחות", g:"f" , smichut:{ssg:"משפחת", spl:"משפחות"} },
  "סבתא": { p:"סבתות", g:"f" },
  "תמונה": { p:"תמונות", g:"f" , smichut:{ssg:"תמונת", spl:"תמונות"} },
  "תרגיל": { p:"תרגילים", g:"m" },
  "תשובה": { p:"תשובות", g:"f" , smichut:{ssg:"תשובת", spl:"תשובות"} },
  "שאלה": { p:"שאלות", g:"f" , smichut:{ssg:"שאלת", spl:"שאלות"} },
  "שמלה": { p:"שמלות", g:"f" },
  "אבן": { p:"אבנים", g:"f", irreg:"f_im", note:"-ים ondanks vrouwelijk" },
  "דבורה": { p:"דבורים", g:"f", irreg:"f_im" },
  "אם": { p:"אמהות", g:"f", note:"sterk onregelmatig" , smichut:{ssg:"אם", spl:"אמהות"} },
  "בת": { p:"בנות", g:"f", note:"sterk onregelmatig" , smichut:{ssg:"בת", spl:"בנות"} },
  "חברה": { p:"חברות", g:"f" , smichut:{ssg:"חברת", spl:"חברות"} },
  "תלמידה": { p:"תלמידות", g:"f" },
  "מורה(f)": { p:"מורות", g:"f" },

  // Bijzondere mannelijke meervouden (-ות)
  "אב": { p:"אבות", g:"m", irreg:"m_otot", note:"-ות bij mannelijk" , smichut:{ssg:"אבי", spl:"אבות"} },
  "שולחן": { p:"שולחנות", g:"m", irreg:"m_otot", note:"-ות bij mannelijk" , smichut:{ssg:"שולחן", spl:"שולחנות"} },
  "מקום": { p:"מקומות", g:"m", irreg:"m_otot", note:"-ות bij mannelijk" , smichut:{ssg:"מקום", spl:"מקומות"} },
  "חלון": { p:"חלונות", g:"m", irreg:"m_otot", note:"-ות bij mannelijk" , smichut:{ssg:"חלון", spl:"חלונות"} },
  "קול": { p:"קולות", g:"m", irreg:"m_otot", note:"-ות bij mannelijk" },
  "אור": { p:"אורות", g:"m", irreg:"m_otot", note:"-ות bij mannelijk" },
  "דור": { p:"דורות", g:"m", irreg:"m_otot", note:"-ות bij mannelijk" },
  "מילון": { p:"מילונים", g:"m" },
  "חשבון": { p:"חשבונות", g:"m", irreg:"m_otot", note:"-ות bij mannelijk" },

  // ל"ה (geen ת/ה einde, m of f sterke afwijking)
  "אצבע": { p:"אצבעות", g:"f" },
  "חצר": { p:"חצרות", g:"f" },
  "לשון": { p:"לשונות", g:"f" },
  "נפש": { p:"נפשות", g:"f" },

  // Duals (זוגי)
  "אוזן": { p:"אוזניים", g:"f", irreg:"dual", note:"duaal" , smichut:{ssg:"אוזן", spl:"אוזני"} },
  "עין": { p:"עיניים", g:"f", irreg:"dual", note:"duaal" , smichut:{ssg:"עין", spl:"עיני"} },
  "יד": { p:"ידיים", g:"f", irreg:"dual", note:"duaal" , smichut:{ssg:"יד", spl:"ידי"} },
  "רגל": { p:"רגליים", g:"f", irreg:"dual", note:"duaal" , smichut:{ssg:"רגל", spl:"רגלי"} },
  "שן": { p:"שיניים", g:"f", irreg:"dual", note:"duaal" },
  "ברך": { p:"ברכיים", g:"f", irreg:"dual", note:"duaal" },
  "שפה": { p:"שפתיים", g:"f", irreg:"dual", note:"duaal" },
  "שוק": { p:"שוקיים", g:"f", irreg:"dual", note:"duaal" },
  "מותן": { p:"מותניים", g:"m", irreg:"dual", note:"duaal" },
  "אופן": { p:"אופניים", g:"m", irreg:"dual", note:"duaal" },
  "נעל": { p:"נעליים", g:"f", irreg:"dual", note:"duaal" },
  "מכנס": { p:"מכנסיים", g:"m", irreg:"dual", note:"duaal" },
  "משקפ": { p:"משקפיים", g:"m", irreg:"dual", note:"duaal" },

  // Hebrew Cards woorden
  "טעות": { p:"טעויות", g:"f" },
  "דירה": { p:"דירות", g:"f" , smichut:{ssg:"דירת", spl:"דירות"} },
  "בית": { p:"בתים", g:"m", note:"onregelmatig stam" , smichut:{ssg:"בית", spl:"בתי"} },
};

// Helper: zoek meervoud en geslacht voor een woord
window.pluralOf = function(word) {
  if (!word) return null;
  if (window.PLURALS_OVERRIDES && window.PLURALS_OVERRIDES[word]) {
    return { ...window.PLURALS_OVERRIDES[word], source: 'user' };
  }
  const e = window.PLURALS_DICT && window.PLURALS_DICT[word];
  if (e) return { ...e, source: 'dict' };
  return null;
};

// User overrides via UI (in localStorage)
window.PLURALS_OVERRIDES = (() => {
  try { return JSON.parse(localStorage.getItem('plurals_overrides') || '{}'); }
  catch(e) { return {}; }
})();
window.editPlural = function(word) {
  const cur = window.pluralOf(word) || {};
  const curP = cur.p || '';
  const curG = cur.g || '';
  const nwP = prompt("Meervoud voor " + word + ":", curP);
  if (nwP === null) return;
  const nwG = prompt("Geslacht (m / f / mf):", curG || 'm');
  if (nwG === null) return;
  const tP = nwP.trim(), tG = nwG.trim();
  if (!tP) {
    delete window.PLURALS_OVERRIDES[word];
  } else {
    window.PLURALS_OVERRIDES[word] = { p: tP, g: (tG || 'm') };
  }
  try { localStorage.setItem('plurals_overrides', JSON.stringify(window.PLURALS_OVERRIDES)); } catch(e) {}
  if (typeof renderVocab === 'function') { S.vocab = null; computeVocab(); renderVocab(); }
};
